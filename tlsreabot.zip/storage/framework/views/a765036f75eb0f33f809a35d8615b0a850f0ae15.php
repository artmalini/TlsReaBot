<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('status')): ?>
            <div class="alert alert-info">
                <span><?php echo e(Session::get('status')); ?></span>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('admin.setting.store')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label>URL TlsReaBot</label>
                <div class="input-group-btn">
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Action <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a href="#" onclick="document.getElementById('url_call_bot').value='<?php echo e(url('')); ?>'">Вставить url</a></li>
                        <li><a href="#" onclick="event.preventDefault(); document.getElementById('setwebhook').submit();">Отправить url</a></li>
                        <li><a href="#" onclick="event.preventDefault(); document.getElementById('getwebhookinfo').submit();">Получить информацию</a></li>
                    </ul>
                </div>
                <input type="url" class="form-control" id="url_call_bot" name="url_call_bot" value="<?php echo e(isset($url_call_bot) ? $url_call_bot : ''); ?>">
            </div>
            <div class="form-group">
                <label>Дополнительная информация</label>
                <input type="text" class="form-control" name="exp_info" value="<?php echo e(isset($exp_info) ? $exp_info : ''); ?>">
            </div>
            <button class="btn btn-primary" type="submit">Отправить</button>
        </form>

         <form id="setwebhook" action="<?php echo e(route('admin.setting.setwebhook')); ?>" method="post" style="display: none;">
             <?php echo e(csrf_field()); ?>

             <input type="hidden" name="url" value="<?php echo e(isset($url_call_bot) ? $url_call_bot : ''); ?>">
         </form>

            <form id="getwebhookinfo" action="<?php echo e(route('admin.setting.getwebhookinfo')); ?>" method="post" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>