@extends('backend.layouts.app')

@section('content')
    <div class="container">
        <hi>Админ панель</hi>
    </div>
@endsection